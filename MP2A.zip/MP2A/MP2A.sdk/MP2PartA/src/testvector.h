#ifndef __TESTVECTOR_H_
#define __TESTVECTOR_H_

int num_test_vectors = 2;
char testvector[2][100]= {"The quick brown fox tried to jump over the fence.","He wasn't very successful, and has the scars to show."};

#endif
